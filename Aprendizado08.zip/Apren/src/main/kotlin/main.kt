fun main(){
    val rogerioProf = Professor(nome = "Rogerio", CPF = 1242514121123, idProf = 27594011)
    val julianaAluno = Aluno(nome = "Juliana", CPF= 32146811650, numCadastro = 4517833)
    println("Professor ${rogerioProf.nome}\nCPF ${rogerioProf.CPF}\nId do Professor ${rogerioProf.idProf}")
    rogerioProf.cursoProfessor()
    rogerioProf.ads()

    println("Aluno ${julianaAluno.nome}\nCPF ${julianaAluno.CPF}\nNumero do Cadastro ${julianaAluno.numCadastro}")
    julianaAluno.hobbies()
    julianaAluno.comer()

}

open class Pessoa(
    open val nome:String = "",
    open val CPF:Long = 0
)

class Professor(
    nome:String,
    CPF:Long,
    val idProf:Long
): Pessoa(nome,CPF), Cursos {
    override fun cursoProfessor() {
        return println("O Professor ministra curso de:")
    }
}

class Aluno(
    nome:String,
    CPF:Long,
    val numCadastro:Long
): Pessoa(nome,CPF), Hobbies {
    override fun hobbies() {
        return println("Os hobbies são:")
    }
}

interface Cursos {
    fun cursoProfessor(){
        return println("especialização\n")
    }
    fun ads(){
        return println("Analise e Desenvolvimento de Sistemas\n")
    }
    fun veterinaria(){
        return println("Veterinária\n")
    }
    fun farmacia(){
        return println("Farmácia\n")
    }
}

interface Hobbies {
    fun hobbies(){
        return println("lazer\n")
    }

    fun limparCasa(){
        return println("Limpar minha casa\n")
    }
    fun assitirFilme(){
        return println("Assistir filmes em família\n")
    }
    fun comer(){
        return println("Comer pratos feitos em família\n")
    }
}